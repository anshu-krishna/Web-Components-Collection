class SVGIcon extends HTMLElement {
	static get template() {
		if (typeof SVGIcon.__template === "undefined") {
			SVGIcon.__template = document.createElement("template");
			SVGIcon.__template.innerHTML = `<style>
:host {
	display: inline-flex;
}
#image {
	display: flex;
	align-items: center;
}
svg {
	fill: currentColor;
	height: 1em;
	width: auto;
}
</style><span id="image"></span>`;
		}
		return SVGIcon.__template;
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(SVGIcon.template.content.cloneNode(true));
		Object.defineProperties(this, {
			__imageNode: {
				enumerable: false,
				writable: false,
				value: this.shadowRoot.querySelector('#image')
			}
		});
		SVGIcon.__loader(this);
	}
	// connectedCallback() {}
	// disconnectedCallback() {}
	// adoptedCallback() {}
	static get observedAttributes() {
		return ['src'];
	}
	get src() {
		return this.getAttribute('src');
	}
	set src(value) {
		if(typeof value === 'string') {
			this.setAttribute('src', value);
		} else {
			this.removeAttribute('src');
		}
	}
	attributeChangedCallback(name, oldval, newval) {
		// console.log("Changed", name, ":", oldval, "->", newval);
		SVGIcon.__loader(this);
	}
}
Object.defineProperties(SVGIcon, {
	__broken: {
		enumerable: false,
		writable: false,
		value: `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 30 30"><g xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" transform="translate(-570 -80)"><circle cx="579" cy="92" r="2"/><path d="M591 86l-1 2h5v15h-9l-1 2h12V86z"/><path d="M586 102h8v-3c-2-3-3-7-5-7l-3 10zm2-20l-1 4h-14v19h8l-1 4h2l8-27h-2zm-5 16l-2-2c-2 0-2 4-5 5v1h6v1h-7V88h11l-3 10z"/></g></svg>`
	},
	__fetcher: {
		enumerable: false,
		writable: false,
		value: async function (url) {
			let data = await fetch(url, {
				mode: 'cors'
			}).then(r => {
				if(r.status === 200) {
					return r.text();
				}
				return false;
			}).catch(e => false);
			return data;
		}
	},
	__loader: {
		enumerable: false,
		writable: false,
		value: function(node) {
			let src = node.src;
			if(src === null) {
				node.__imageNode.innerHTML = SVGIcon.__broken;
			} else {
				SVGIcon.__fetcher(src).then(data => {
					if(data === false) {
						node.__imageNode.innerHTML = SVGIcon.__broken;
					} else {
						node.__imageNode.innerHTML = data;
					}
				});
			}
		}
	}
});
customElements.define("svg-icon", SVGIcon);