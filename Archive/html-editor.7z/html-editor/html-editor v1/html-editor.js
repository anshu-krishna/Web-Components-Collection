class HTMLEditor extends HTMLElement {
	static get template() {
		if (typeof HTMLEditor._template == "undefined") {
			HTMLEditor._template = document.createElement("template");
			HTMLEditor._template.innerHTML = `<link rel="stylesheet" href="${HTMLEditor._path}/font/font.css" /><style>
:host() {
	display: block;
}
[data-toolbar-cntr], [data-toolbar2-cntr] {
	display: flex;
	flex-wrap: wrap;
	box-shadow: 0 0 5px;
}
[data-toolbar-cntr] [data-spacer], [data-toolbar2-cntr] [data-spacer] {
	display: inline-block;
	width: 0px;
	margin: 0 2px;
}
[data-toolbar-cntr] button, [data-toolbar2-cntr] button {
	display: inline-block;
	background: #efefef;
	font-size: 1em;
	height: 2em;
	min-width: 2em;
	padding: 3px;
	cursor: pointer;
	margin: 0;
	border: none;
}
[data-toolbar-cntr] button:hover, [data-toolbar2-cntr] button:hover {
	border-bottom: 1px solid;
}
[data-toolbar-cntr] button:active, [data-toolbar2-cntr] button:active {
	box-shadow: 0 0 0.5em inset;
}
[data-button-font] {
	font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}
[data-content-cntr], [data-content-source] {
	min-height: 2em;
	padding: 5px 10px;
}
[data-content-cntr] {
	display: block;
}
[data-content-source] {
	white-space: pre-wrap;
	word-wrap: break-word;
}
[data-content-source], [data-editor-hidden], button[data-editor-hidden] {
	display: none;
}

</style><div>
<div data-toolbar-cntr>
<button data-editor-hidden data-type="no-value" data-command="selectAll" data-shortcut="ctrl+a"></button>
<button data-editor-hidden data-type="valued" data-command="insertHTML" data-value="<br>\u200C" data-shortcut="ctrl+13"></button>
<button data-icon-font data-type="no-value" data-command="undo" data-shortcut="ctrl+z" title="Undo (Ctrl+Z)">&#xf0e2;</button>
<button data-icon-font data-type="no-value" data-command="redo" data-shortcut="ctrl+y" title="Redo (Ctrl+Y)">&#xf01e;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="cut" data-shortcut="ctrl+x" title="Cut (Ctrl+X)">&#xf0c4;</button>
<button data-icon-font data-type="copy-paste" data-command="copy" data-shortcut="ctrl+c" title="Copy (Ctrl+C)">&#xf0c5;</button>
<button data-icon-font data-type="copy-paste" data-command="paste" data-shortcut="ctrl+v" title="Paste (Ctrl+V)">&#xf0ea;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="bold" data-shortcut="ctrl+b" title="Bold (Ctrl+B)">&#xf032;</button>
<button data-icon-font data-type="no-value" data-command="italic" data-shortcut="ctrl+i" title="Italic (Ctrl+I)">&#xf033;</button>
<button data-icon-font data-type="no-value" data-command="underline" data-shortcut="ctrl+u" title="Underline (Ctrl+U)">&#xf0cd;</button>
<button data-icon-font data-type="no-value" data-command="strikeThrough" title="Strike Through">&#xf0cc;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="justifyLeft" data-shortcut="ctrl+l" title="Justify Left (Ctrl+L)">&#xf036;</button>
<button data-icon-font data-type="no-value" data-command="justifyCenter" data-shortcut="ctrl+e" title="Justify Center (Ctrl+E)">&#xf037;</button>
<button data-icon-font data-type="no-value" data-command="justifyRight" data-shortcut="ctrl+r" title="Justify Right (Ctrl+R)">&#xf038;</button>
<button data-icon-font data-type="no-value" data-command="justifyFull" data-shortcut="ctrl+j" title="Justify (Ctrl+J)">&#xf039;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="indent" title="Indent">&#xf03c;</button>
<button data-icon-font data-type="no-value" data-command="outdent" title="Outdent">&#xf03b;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="subscript" title="Subscript">&#xf12c;</button>
<button data-icon-font data-type="no-value" data-command="superscript" title="Superscript">&#xf12b;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="insertUnorderedList" title="Insert Unordered List">&#xf0ca;</button>
<button data-icon-font data-type="no-value" data-command="insertOrderedList" title="Insert Ordered List">&#xf0cb;</button>
<span data-spacer></span>
<button data-button-font data-type="block-style" data-command="h1" title="Insert H1 Tag"><strong>H1</strong></button>
<button data-button-font data-type="block-style" data-command="h2" title="Insert H2 Tag"><strong>H2</strong></button>
<button data-button-font data-type="block-style" data-command="h3" title="Insert H3 Tag"><strong>H3</strong></button>
<button data-button-font data-type="block-style" data-command="h4" title="Insert H4 Tag"><strong>H4</strong></button>
<button data-button-font data-type="block-style" data-command="h5" title="Insert H5 Tag"><strong>H5</strong></button>
<button data-button-font data-type="block-style" data-command="h6" title="Insert H6 Tag"><strong>H6</strong></button>
<button data-button-font data-type="valued" data-command="insertHTML" data-value="<hr>\u200c" title="Insert Horizontal Rule"><strong>HR</strong></button>
<button data-button-font data-type="valued" data-command="insertHTML" data-value="<p></p>" title="Insert Paragraph"><strong>P</strong></button>
<span data-spacer></span>
<button data-button-font data-type="custom" data-command="source" title="View Source">&lt;Source&gt;</button>
</div>

<div data-toolbar2-cntr data-editor-hidden>
<button data-editor-hidden data-type="no-value" data-command="selectAll" data-shortcut="ctrl+a"></button>
<button data-icon-font data-type="no-value" data-command="undo" data-shortcut="ctrl+z" title="Undo (Ctrl+Z)">&#xf0e2;</button>
<button data-icon-font data-type="no-value" data-command="redo" data-shortcut="ctrl+y" title="Redo (Ctrl+Y)">&#xf01e;</button>
<span data-spacer></span>
<button data-icon-font data-type="no-value" data-command="cut" data-shortcut="ctrl+x" title="Cut (Ctrl+X)">&#xf0c4;</button>
<button data-icon-font data-type="copy-paste" data-command="copy" data-shortcut="ctrl+c" title="Copy (Ctrl+C)">&#xf0c5;</button>
<button data-icon-font data-type="copy-paste" data-command="paste" data-shortcut="ctrl+v" title="Paste (Ctrl+V)">&#xf0ea;</button>
<span data-spacer></span>
<button data-button-font data-type="custom" data-command="editor" title="View Rich-Text Editor">Editor Mode</button>
</div>

<div data-content-cntr contenteditable="true"></div>
<pre data-content-source contenteditable="true"></pre>
<div data-editor-hidden><slot data-preset-content></slot></div>
</div>`;
		}
		return HTMLEditor._template;
	}
	static _filterContent(content) {
		content = content.replace(/<\s*script(.*)>/g, "&lt;script$1&gt;");
		content = content.replace(/<\s*\/script(.*)>/g, "&lt;\/script$1&gt;");
		content = content.replace(/\s*class="style-scope html-editor"/g, "");
		content = content.replace(/class="([^\\s]*)?\s*style-scope html-editor"/g, "class=\"$1\"");
		return content;
	}
	static _filterButtonShortcut(nodes) {
		nodes = Array.from(nodes);
		nodes = nodes.filter(node => {
			if (node.nodeType == 1 && node.tagName.toLowerCase() == "button") {
				let shortcut = node.getAttribute("data-shortcut");
				if (shortcut === null) return false;
				shortcut = shortcut.toLowerCase().split("+");
				if (shortcut.length < 2) return false;
				for (let i = shortcut.length - 2; i >= 0; i--) {
					if (!(shortcut[i] == "ctrl" || shortcut[i] == "alt")) return false;
				}
				return true;
			}
			return false;
		});
		nodes = nodes.map(node => {
			let shortcut = node.getAttribute("data-shortcut").toLowerCase().split("+");
			let modifier = {
				ctrl: false,
				alt: false
			};
			for (let i = shortcut.length - 2; i >= 0; i--) {
				if (shortcut[i] == "ctrl") {
					modifier.ctrl = true;
				} else if (shortcut[i] == "alt") {
					modifier.alt = true;
				}
			}
			let key = shortcut[shortcut.length - 1];
			key = isNaN(key) ? key.charCodeAt(0) : parseInt(key);
			return {
				button: node,
				modifier: modifier,
				key: key
			}
		});
		return nodes;
	}
	get value() {
		if (this.mode == "editor") {
			return HTMLEditor._filterContent(this._elements.contentCntr.innerHTML);
		}
		return HTMLEditor._filterContent(this._elements.contentSource.innerText);
	}
	set value(html) {
		if (this.mode == "editor") {
			this._elements.contentCntr.innerHTML = html;
		} else {
			this._elements.contentSource.innerText = html;
		}
	}
	get mode() {
		return this._elements.contentCntr.hasAttribute("data-editor-hidden") ? "source" : "editor";
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(HTMLEditor.template.content.cloneNode(true));
		this._elements = {
			toolbarCntr: this.shadowRoot.querySelector("[data-toolbar-cntr]"),
			toolbar2Cntr: this.shadowRoot.querySelector("[data-toolbar2-cntr]"),
			contentSlot: this.shadowRoot.querySelector("slot[data-preset-content]"),
			contentCntr: this.shadowRoot.querySelector("[data-content-cntr]"),
			contentSource: this.shadowRoot.querySelector("[data-content-source]")
		};
		let presetContent = Array.from(this._elements.contentSlot.assignedNodes());
		presetContent = presetContent.map(v => (v.nodeType == 3) ? v.nodeValue : ((v.nodeType == 1) ? v.outerHTML : "")).join("").trim();
		presetContent = HTMLEditor._filterContent(presetContent);
		this._elements.contentCntr.innerHTML = presetContent;
		this._shortcuts = {
			toolbar: HTMLEditor._filterButtonShortcut(this.shadowRoot.querySelectorAll("[data-toolbar-cntr] button")),
			toolbar2: HTMLEditor._filterButtonShortcut(this.shadowRoot.querySelectorAll("[data-toolbar2-cntr] button"))
		};
		// console.log(this._shortcuts.toolbar);
		// console.log(this._shortcuts.toolbar2);
	}
	_shortcutListener(e) {
		let modifier = {
			alt: e.getModifierState("Alt"),
			ctrl: e.getModifierState("Control")
		},
			key = e.which || e.keyCode;
		if (!(modifier.ctrl || modifier.alt)) return;
		e.preventDefault(); e.stopPropagation();
		let shortcut = (this._elements.toolbarCntr.hasAttribute("data-editor-hidden")) ? this._shortcuts.toolbar2 : this._shortcuts.toolbar;
		shortcut = shortcut.filter(s => {
			if (s.modifier.alt == modifier.alt
				&& s.modifier.ctrl == modifier.ctrl
				&& s.key == key) return true;
			return false;
		});
		for (let s of shortcut) {
			s.button.click();
		}
	}
	_clickListener(e) {
		e.preventDefault();
		e.stopPropagation();
		let command = e.target.getAttribute("data-command");
		if (command === null) return;
		let type = e.target.getAttribute("data-type");
		this.dispatchEvent(new CustomEvent("command", { detail: { command: command, type: type, button: e.target } }));
	}

	_customCommand(command, button) {
		// console.log("Custom Command", button);
		switch (command) {
			case "source":
				this._elements.contentSource.innerText = HTMLEditor._filterContent(this._elements.contentCntr.innerHTML);

				this._elements.contentCntr.setAttribute("data-editor-hidden", "");
				this._elements.contentSource.style.display = "block";

				this._elements.toolbarCntr.setAttribute("data-editor-hidden", "");
				this._elements.toolbar2Cntr.removeAttribute("data-editor-hidden");
				break;
			case "editor":
				this._elements.contentCntr.innerHTML = HTMLEditor._filterContent(this._elements.contentSource.innerText);
				this._elements.contentCntr.removeAttribute("data-editor-hidden");
				this._elements.contentSource.style.display = null;

				this._elements.toolbarCntr.removeAttribute("data-editor-hidden");
				this._elements.toolbar2Cntr.setAttribute("data-editor-hidden", "");
				break;
		}
	}
	_commandHandler({ detail: { command, type, button } }) {
		console.log("Command Event ->", command, type, button);
		switch (type) {
			case "custom":
				this._customCommand(command, button);
				break;
			case "valued":
				document.execCommand(command, false, button.getAttribute("data-value"));
				break;
			case "block-style":
				document.execCommand('formatBlock', false, command);
				break;
			case "copy-paste":
				// if (command == "copy" || command == "paste")
				if (this.mode == "editor") {
					this._elements.contentCntr.focus();
				} else {
					this._elements.contentSource.focus();
				}
				document.execCommand(command, false, null);
				break;
			case "no-value":
			default:
				document.execCommand(command, false, null);
				break;
		}
	}
	connectedCallback() {
		this._elements.toolbarCntr.addEventListener("click", this._clickListener.bind(this));
		this._elements.toolbar2Cntr.addEventListener("click", this._clickListener.bind(this));
		this.addEventListener("keypress", this._shortcutListener.bind(this));
		this.addEventListener("command", this._commandHandler.bind(this));
	}
	// disconnectedCallback() {}
	// adoptedCallback() {}
	// static get observedAttributes() {}
	// attributeChangedCallback(name, oldval, newval) {
	//	console.log("Changed", name, ":", oldval, "->", newval);
	//}
}
HTMLEditor._path = document.currentScript.src;
HTMLEditor._path = HTMLEditor._path.substring(0, HTMLEditor._path.lastIndexOf("/"));
customElements.define("html-editor", HTMLEditor);