class DefaultHTMLEditorTools {
	static get(name, ...cssClasses) {
		if (typeof DefaultHTMLEditorTools._toolsData[name] == "undefined") return null;
		let button = document.createElement("button");
		let tool = DefaultHTMLEditorTools._toolsData[name];
		if (typeof tool.svg != "undefined") {
			let svg = {
				start: `<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">`,
				end: `</svg>`
			}
			button.innerHTML = svg.start + tool.svg + svg.end;
		}
		(typeof tool.html != "undefined") && (button.innerHTML = tool.html);
		(typeof tool.command != "undefined") && button.setAttribute("data-command", tool.command);
		(typeof tool.type != "undefined") && button.setAttribute("data-type", tool.type);
		(typeof tool.value != "undefined") && button.setAttribute("data-value", tool.value);
		(typeof tool.shortcut != "undefined") && button.setAttribute("data-shortcut", tool.shortcut);
		(typeof tool.tooltip != "undefined") && button.setAttribute("title", tool.tooltip);
		if (typeof tool.cssClass != "undefined") {
			if (Array.isArray(tool.cssClass)) {
				for (let c of tool.cssClass) {
					button.classList.add(c);
				}
			} else {
				button.classList.add(tool.cssClass);
			}
		}
		for (let c of cssClasses) {
			button.classList.add(c);
		}
		return button;
	}
	static getToolContainer(cntrText = "", ...cssClasses) {
		let div = document.createElement("div");
		div.classList.add("html_editor_tool_cntr");
		div.setAttribute("role", "button");
		div.innerHTML = cntrText;
		let d2 = document.createElement("div");
		d2.classList.add("html_editor_tool_cntr_content");
		div.appendChild(d2);
		for (let c of cssClasses) {
			div.classList.add(c);
		}
		return {
			cntr: div,
			content: d2
		};
	}
	static getDefaultToolbars() {
		let toolbar = {
			html: document.createElement("div"),
			source: document.createElement("div")
		};
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("selectAll"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("insertBr"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("undo"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("redo"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("cut"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("copy"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("paste"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("bold"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("italic"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("underline"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("strikeThrough"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		let toolCntr = DefaultHTMLEditorTools.getToolContainer("Insert Tag");
		toolbar.html.appendChild(toolCntr.cntr);
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertDiv"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertP"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH1"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH2"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH3"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH4"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH5"));
		toolCntr.content.appendChild(DefaultHTMLEditorTools.get("insertH6"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("alignLeft"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("alignCenter"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("alignRight"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("alignJustify"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("indentRight"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("indentLeft"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("subscript"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("superscript"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("listUl"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("listOl"));

		toolbar.html.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.html.appendChild(DefaultHTMLEditorTools.get("viewSourceEditor"));

		toolbar.source.appendChild(DefaultHTMLEditorTools.get("selectAll"));

		toolbar.source.appendChild(DefaultHTMLEditorTools.get("undo"));
		toolbar.source.appendChild(DefaultHTMLEditorTools.get("redo"));

		toolbar.source.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.source.appendChild(DefaultHTMLEditorTools.get("cut"));
		toolbar.source.appendChild(DefaultHTMLEditorTools.get("copy"));
		toolbar.source.appendChild(DefaultHTMLEditorTools.get("paste"));

		toolbar.source.appendChild(DefaultHTMLEditorTools.get("spacer"));
		toolbar.source.appendChild(DefaultHTMLEditorTools.get("viewHTMLEditor"));
		return toolbar;
	}
}
DefaultHTMLEditorTools._toolsData = {
	alignCenter: {
		svg: `<path d="M0 2h32v4h-32zM6 8h20v4h-20zM6 20h20v4h-20zM0 14h32v4h-32zM0 26h32v4h-32z"></path>`,
		command: "justifyCenter",
		type: "no-value",
		shortcut: "ctrl+e",
		tooltip: "Align Center (Ctrl+E)"
	},
	alignJustify: {
		svg: `<path d="M0 2h32v4h-32zM0 8h32v4h-32zM0 14h32v4h-32zM0 20h32v4h-32zM0 26h32v4h-32z"></path>`,
		command: "justifyFull",
		type: "no-value",
		shortcut: "ctrl+j",
		tooltip: "Justify (Ctrl+J)"
	},
	alignLeft: {
		svg: `<path d="M0 2h32v4h-32zM0 8h20v4h-20zM0 20h20v4h-20zM0 14h32v4h-32zM0 26h32v4h-32z"></path>`,
		command: "justifyLeft",
		type: "no-value",
		shortcut: "ctrl+l",
		tooltip: "Align Left (Ctrl+L)"
	},
	alignRight: {
		svg: `<path d="M0 2h32v4h-32zM12 8h20v4h-20zM12 20h20v4h-20zM0 14h32v4h-32zM0 26h32v4h-32z"></path>`,
		command: "justifyRight",
		type: "no-value",
		shortcut: "ctrl+r",
		tooltip: "Align Right (Ctrl+R)"
	},
	bold: {
		svg: `<path d="M22.121 15.145c1.172-1.392 1.879-3.188 1.879-5.145 0-4.411-3.589-8-8-8h-10v28h12c4.411 0 8-3.589 8-8 0-2.905-1.556-5.453-3.879-6.855zM12 6h3.172c1.749 0 3.172 1.794 3.172 4s-1.423 4-3.172 4h-3.172v-8zM16.969 26h-4.969v-8h4.969c1.827 0 3.313 1.794 3.313 4s-1.486 4-3.313 4z"></path>`,
		command: "bold",
		type: "no-value",
		shortcut: "ctrl+b",
		tooltip: "Bold (Ctrl+B)"
	},
	copy: {
		svg: `<path d="M20 8v-8h-14l-6 6v18h12v8h20v-24h-12zM6 2.828v3.172h-3.172l3.172-3.172zM2 22v-14h6v-6h10v6l-6 6v8h-10zM18 10.828v3.172h-3.172l3.172-3.172zM30 30h-16v-14h6v-6h10v20z"></path>`,
		command: "copy",
		type: "copy-paste",
		shortcut: "ctrl+c",
		tooltip: "Copy (Ctrl+C)"
	},
	cut: {
		svg: `<path d="M28.557 21.24c-2.084-3.256-5.659-4.689-7.985-3.201-0.201 0.129-0.385 0.275-0.555 0.437l-2.483-3.883 5.733-8.999c0.469-0.867 0.642-1.899 0.415-2.937-0.218-0.992-0.766-1.826-1.503-2.413l-0.384-0.244-6.796 10.629-6.796-10.629-0.384 0.244c-0.737 0.587-1.285 1.421-1.503 2.413-0.228 1.038-0.055 2.070 0.415 2.937l5.733 8.999-2.483 3.883c-0.169-0.162-0.354-0.308-0.554-0.437-2.326-1.488-5.901-0.055-7.985 3.201s-1.887 7.103 0.438 8.591c2.326 1.488 5.901 0.055 7.985-3.201l5.134-8.058 5.134 8.058c2.084 3.256 5.659 4.689 7.985 3.201s2.522-5.335 0.438-8.591zM7.339 25.013c-0.938 1.466-2.142 2.179-2.955 2.358-0 0-0 0-0 0-0.265 0.058-0.634 0.094-0.885-0.067-0.278-0.178-0.463-0.648-0.494-1.259-0.050-0.989 0.301-2.151 0.965-3.189 0.938-1.466 2.142-2.179 2.955-2.358 0.266-0.058 0.635-0.094 0.886 0.066 0.278 0.178 0.463 0.648 0.494 1.259 0.051 0.989-0.301 2.151-0.965 3.189zM15 16c-0.552 0-1-0.448-1-1s0.448-1 1-1 1 0.448 1 1-0.448 1-1 1zM26.995 26.046c-0.031 0.61-0.216 1.081-0.494 1.259-0.251 0.161-0.62 0.125-0.885 0.067 0 0 0 0-0 0-0.814-0.179-2.017-0.892-2.955-2.358-0.664-1.037-1.016-2.2-0.965-3.189 0.031-0.61 0.216-1.081 0.494-1.259 0.251-0.16 0.62-0.125 0.886-0.066 0.814 0.179 2.017 0.892 2.955 2.358 0.664 1.037 1.016 2.2 0.965 3.189z"></path>`,
		command: "cut",
		type: "no-value",
		shortcut: "ctrl+x",
		tooltip: "Cut (Ctrl+X)"
	},
	indentLeft: {
		svg: `<path d="M0 2h32v4h-32zM12 8h20v4h-20zM12 14h20v4h-20zM12 20h20v4h-20zM0 26h32v4h-32zM8 10v12l-8-6z"></path>`,
		command: "outdent",
		type: "no-value",
		tooltip: "Outdent"
	},
	indentRight: {
		svg: `<path d="M0 2h32v4h-32zM12 8h20v4h-20zM12 14h20v4h-20zM12 20h20v4h-20zM0 26h32v4h-32zM0 22v-12l8 6z"></path>`,
		command: "indent",
		type: "no-value",
		tooltip: "Indent"
	},
	insertBr: {
		html: "Insert Br",
		command: "insertHTML",
		type: "valued",
		value: "<br>\u200C",
		shortcut: "ctrl+13",
		cssClass: "html_editor_hidden"
	},
	insertDiv: {
		html: "DIV",
		command: "insertHTML",
		type: "valued",
		value: "<div></div>",
		tooltip: "Insert Div"
	},
	insertH1: {
		html: "H1",
		command: "h1",
		type: "block",
		tooltip: "Insert H1"
	},
	insertH2: {
		html: "H2",
		command: "h2",
		type: "block",
		tooltip: "Insert H2"
	},
	insertH3: {
		html: "H3",
		command: "h3",
		type: "block",
		tooltip: "Insert H3"
	},
	insertH4: {
		html: "H4",
		command: "h4",
		type: "block",
		tooltip: "Insert H4"
	},
	insertH5: {
		html: "H5",
		command: "h5",
		type: "block",
		tooltip: "Insert H5"
	},
	insertH6: {
		html: "H6",
		command: "h6",
		type: "block",
		tooltip: "Insert H6"
	},
	insertHr: {
		html: "HR",
		command: "insertHTML",
		type: "valued",
		value: "<hr>\u200C",
		tooltip: "Insert Horizontal Rule"
	},
	insertP: {
		html: "P",
		command: "insertHTML",
		type: "valued",
		value: "<p></p>",
		tooltip: "Insert Paragraph"
	},
	italic: {
		svg: `<path d="M28 2v2h-4l-10 24h4v2h-14v-2h4l10-24h-4v-2z"></path>`,
		command: "italic",
		type: "no-value",
		shortcut: "ctrl+i",
		tooltip: "Italic (Ctrl+I)"
	},
	listOl: {
		svg: `<path d="M12 26h20v4h-20zM12 14h20v4h-20zM12 2h20v4h-20zM6 0v8h-2v-6h-2v-2zM4 16.438v1.563h4v2h-6v-4.563l4-1.875v-1.563h-4v-2h6v4.563zM8 22v10h-6v-2h4v-2h-4v-2h4v-2h-4v-2z"></path>`,
		command: "insertOrderedList",
		type: "no-value",
		tooltip: "Insert Ordered List"
	},
	listUl: {
		svg: `<path d="M12 2h20v4h-20v-4zM12 14h20v4h-20v-4zM12 26h20v4h-20v-4zM0 4c0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.209-1.791 4-4 4s-4-1.791-4-4zM0 16c0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.209-1.791 4-4 4s-4-1.791-4-4zM0 28c0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.209-1.791 4-4 4s-4-1.791-4-4z"></path>`,
		command: "insertUnorderedList",
		type: "no-value",
		tooltip: "Insert Unordered List"
	},
	paste: {
		svg: `<path d="M22 4h-4v-2c0-1.1-0.9-2-2-2h-4c-1.1 0-2 0.9-2 2v2h-4v4h16v-4zM16 4h-4v-1.996c0.001-0.001 0.002-0.002 0.004-0.004h3.993c0.001 0.001 0.003 0.002 0.004 0.004v1.996zM26 10v-5c0-0.55-0.45-1-1-1h-2v2h1v4h-6l-6 6v8h-8v-18h1v-2h-2c-0.55 0-1 0.45-1 1v20c0 0.55 0.45 1 1 1h9v6h20v-22h-6zM18 12.828v3.172h-3.172l3.172-3.172zM30 30h-16v-12h6v-6h10v18z"></path>`,
		command: "paste",
		type: "copy-paste",
		shortcut: "ctrl+v",
		tooltip: "Paste (Ctrl+V)"
	},
	redo: {
		svg: `<path d="M18 7.762v-7.762l12 12-12 12v-7.932c-13.961-0.328-13.362 9.493-9.808 15.932-8.772-9.482-6.909-24.674 9.808-24.238z"></path>`,
		command: "redo",
		type: "no-value",
		shortcut: "ctrl+r",
		tooltip: "Redo (Ctrl+Y)"
	},
	selectAll: {
		html: "Select All",
		command: "selectAll",
		type: "no-value",
		shortcut: "ctrl+a",
		cssClass: "html_editor_hidden"
	},
	spacer: {
		cssClass: "html_editor_spacer"
	},
	strikeThrough: {
		svg: `<path d="M32 16v2h-7.328c0.86 1.203 1.328 2.584 1.328 4 0 2.215-1.146 4.345-3.143 5.843-1.855 1.391-4.29 2.157-6.857 2.157s-5.002-0.766-6.857-2.157c-1.998-1.498-3.143-3.628-3.143-5.843h4c0 2.168 2.748 4 6 4s6-1.832 6-4c0-2.168-2.748-4-6-4h-16v-2h9.36c-0.073-0.052-0.146-0.104-0.217-0.157-1.998-1.498-3.143-3.628-3.143-5.843s1.146-4.345 3.143-5.843c1.855-1.391 4.29-2.157 6.857-2.157s5.002 0.766 6.857 2.157c1.997 1.498 3.143 3.628 3.143 5.843h-4c0-2.168-2.748-4-6-4s-6 1.832-6 4c0 2.168 2.748 4 6 4 2.468 0 4.814 0.709 6.64 2h9.36z"></path>`,
		command: "strikeThrough",
		type: "no-value",
		tooltip: "Strike-through"
	},
	subscript: {
		svg: `<path d="M24 28.438v1.563h4v2h-6v-4.563l4-1.875v-1.563h-4v-2h6v4.563zM21.125 8h-4.25l-5.875 5.875-5.875-5.875h-4.25l8 8-8 8h4.25l5.875-5.875 5.875 5.875h4.25l-8-8z"></path>`,
		command: "subscript",
		type: "no-value",
		tooltip: "Subscript"
	},
	superscript: {
		svg: `<path d="M24 6.438v1.563h4v2h-6v-4.563l4-1.875v-1.563h-4v-2h6v4.563zM21.125 8h-4.25l-5.875 5.875-5.875-5.875h-4.25l8 8-8 8h4.25l5.875-5.875 5.875 5.875h4.25l-8-8z"></path>`,
		command: "superscript",
		type: "no-value",
		tooltip: "Superscript"
	},
	underline: {
		svg: `<path d="M22 2h4v13c0 4.971-4.477 9-10 9s-10-4.029-10-9v-13h4v13c0 1.255 0.57 2.459 1.605 3.391 1.153 1.038 2.714 1.609 4.395 1.609s3.242-0.572 4.395-1.609c1.035-0.931 1.605-2.136 1.605-3.391v-13zM6 26h20v4h-20z"></path>`,
		command: "underline",
		type: "no-value",
		shortcut: "ctrl+u",
		tooltip: "Underline (Ctrl+U)"
	},
	undo: {
		svg: `<path d="M23.808 32c3.554-6.439 4.153-16.26-9.808-15.932v7.932l-12-12 12-12v7.762c16.718-0.436 18.58 14.757 9.808 24.238z"></path>`,
		command: "undo",
		type: "no-value",
		shortcut: "ctrl+z",
		tooltip: "Undo (Ctrl+Z)"
	},
	viewHTMLEditor: {
		html: "HTML Editor",
		command: "editor",
		type: "mode",
		tooltip: "View HTML Editor"
	},
	viewSourceEditor: {
		html: "&lt;Source&gt;",
		command: "source",
		type: "mode",
		tooltip: "View Source"
	}
};