class HTMLEditor extends HTMLElement {
	static get template() {
		if (typeof HTMLEditor._template == "undefined") {
			let toolbars = DefaultHTMLEditorTools.getDefaultToolbars();

			HTMLEditor._template = document.createElement("template");
			HTMLEditor._template.innerHTML = `<link rel="stylesheet" href="${HTMLEditor._path}/html-editor-template.css" />
<div class="html_editor_internal_container">
<div class="html_editor_toolbar" data-html-toolbar><slot name="html_toolbar">${toolbars.html.innerHTML}</slot></div>
<div class="html_editor_toolbar html_editor_hidden" data-source-toolbar><slot name="source_toolbar">${toolbars.source.innerHTML}</slot></div>
<div class="html_editor_content_container" data-html-container contenteditable="true"></div>
<pre class="html_editor_content_container html_editor_hidden" data-source-container contenteditable="true"></pre>
<div class="html_editor_hidden" data-preset-content><slot></slot></div>
</div>`;
		}
		return HTMLEditor._template;
	}
	static _filterContent(content) {
		content = content.replace(/<\s*script(.*)>/g, "&lt;script$1&gt;");
		content = content.replace(/<\s*\/script(.*)>/g, "&lt;\/script$1&gt;");
		content = content.replace(/\s*class="style-scope html-editor"/g, "");
		content = content.replace(/class="([^\\s]*)?\s*style-scope html-editor"/g, "class=\"$1\"");
		return content;
	}
	static _extractShortcuts(nodes) {
		nodes = nodes.filter(node => {
			if (node.nodeType == 1 && node.tagName.toLowerCase() == "button") {
				let shortcut = node.getAttribute("data-shortcut");
				if (shortcut === null) return false;
				shortcut = shortcut.toLowerCase().split("+");
				if (shortcut.length < 2) return false;
				for (let i = shortcut.length - 2; i >= 0; i--) {
					if (!(shortcut[i] == "ctrl" || shortcut[i] == "alt")) return false;
				}
				return true;
			}
			return false;
		});
		nodes = nodes.map(node => {
			let shortcut = node.getAttribute("data-shortcut").toLowerCase().split("+");
			let modifier = {
				ctrl: false,
				alt: false
			};
			for (let i = shortcut.length - 2; i >= 0; i--) {
				if (shortcut[i] == "ctrl") {
					modifier.ctrl = true;
				} else if (shortcut[i] == "alt") {
					modifier.alt = true;
				}
			}
			let key = shortcut[shortcut.length - 1];
			key = isNaN(key) ? key.charCodeAt(0) : parseInt(key);
			return {
				button: node,
				modifier: modifier,
				key: key
			}
		});
		return nodes;
	}
	static _assignedNodesToHTML(slot) {
		let content = Array.from(slot.assignedNodes());
		content = content.map(v => {
			if (v.nodeType == 3) return v.nodeValue;
			if (v.nodetype == 1) return v.outerHTML;
			return "";
			// return (v.nodeType == 3) ? v.nodeValue : ((v.nodeType == 1) ? v.outerHTML : "");
		}).join("").trim();
		return HTMLEditor._filterContent(content);
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(HTMLEditor.template.content.cloneNode(true));
		this._mode = "html";
		this._nodes = {
			toolbar: {
				html: this.shadowRoot.querySelector("[data-html-toolbar]"),
				source: this.shadowRoot.querySelector("[data-source-toolbar]")
			},
			content: {
				html: this.shadowRoot.querySelector("[data-html-container]"),
				source: this.shadowRoot.querySelector("[data-source-container]")
			},
			toolbarSlot: {
				html: this.shadowRoot.querySelector("[data-html-toolbar] slot"),
				source: this.shadowRoot.querySelector("[data-source-toolbar] slot")
			},
			presetContent: this.shadowRoot.querySelector("[data-preset-content] slot")
		}
		this._observer = {
			htmlToolbarSlot: new MutationObserver(() => {
				this._setupShortcuts("html");
			})
		};
		this._observer.preset = (this._nodes.presetContent === null) ? null : (new MutationObserver(() => {
			this._observer.preset.disconnect();
			delete this._observer.preset;
			this.value = HTMLEditor._assignedNodesToHTML(this._nodes.presetContent);
		}));
		this._shortcuts = {
			html: [],
			source: []
		};
	}
	_setupShortcuts(toolbarType) {
		this._shortcuts[toolbarType] = HTMLEditor._extractShortcuts((this._nodes.toolbarSlot[toolbarType]).assignedNodes({ flatten: true }));
	}
	connectedCallback() {
		let presetContent = HTMLEditor._assignedNodesToHTML(this._nodes.presetContent);
		this._nodes.content.html.innerHTML = presetContent;
		this._nodes.content.source.innerText = presetContent;

		this._setupShortcuts("html");
		this._setupShortcuts("source");

		let clickListener = this._clickListener.bind(this);
		this._nodes.toolbar.html.addEventListener("click", clickListener);
		this._nodes.toolbar.source.addEventListener("click", clickListener);

		this.addEventListener("command", this._commandHandler.bind(this));
		this.addEventListener("keypress", this._shortcutListener.bind(this));

		this._observer.htmlToolbarSlot.observe(this, {
			childList: true,
			subtree: true
		});

		this._observer.preset.observe(this, {
			attributes: true,
			childList: true,
			subtree: true,
			characterData: true
		});
	}
	// disconnectedCallback() { }
	// adoptedCallback() {}
	// static get observedAttributes() {}
	// attributeChangedCallback(name, oldval, newval) {
	//	console.log("Changed", name, ":", oldval, "->", newval);
	//}
	_clickListener(e) {
		e.preventDefault();
		e.stopPropagation();
		let button = e.target;
		while (button.nodeName.toLowerCase() != "button" && !this.isSameNode(button)) {
			button = button.parentNode;
		}
		if (button.nodeName.toLowerCase() != "button") return;
		let command = button.getAttribute("data-command");
		if (command === null) return;
		let type = button.getAttribute("data-type");
		this.dispatchEvent(new CustomEvent("command", { detail: { command: command, type: type, button: button } }));
	}
	_shortcutListener(e) {
		let modifier = {
			alt: e.getModifierState("Alt"),
			ctrl: e.getModifierState("Control")
		},
			key = e.which || e.keyCode;
		if (!(modifier.ctrl || modifier.alt)) return;
		e.preventDefault(); e.stopPropagation();
		let shortcut = (this.mode == "html") ? this._shortcuts.html : this._shortcuts.source;
		shortcut = shortcut.filter(s => {
			if (s.modifier.alt == modifier.alt
				&& s.modifier.ctrl == modifier.ctrl
				&& s.key == key) return true;
			return false;
		});
		for (let s of shortcut) {
			s.button.click();
		}
	}
	_customCommand(command, button) {
		// console.log("Custom Command", button);
		// switch (command) {
		// 	case "":
		// 		break;
		// }
	}
	_commandHandler({ detail: { command, type, button } }) {
		// console.log("Command Event ->", command, type, button);
		switch (type) {
			case "custom":
				this._customCommand(command, button);
				break;
			case "valued":
				document.execCommand(command, false, button.getAttribute("data-value"));
				if (this.mode == "html") {
					this._nodes.content.html.focus();
				} else {
					this._nodes.content.source.focus();
				}
				break;
			case "block":
				document.execCommand('formatBlock', false, command);
				if (this.mode == "html") {
					this._nodes.content.html.focus();
				} else {
					this._nodes.content.source.focus();
				}
				break;
			case "copy-paste":
				// if (command == "copy" || command == "paste")
				if (this.mode == "html") {
					this._nodes.content.html.focus();
				} else {
					this._nodes.content.source.focus();
				}
				document.execCommand(command, false, null);
				break;
			case "mode":
				switch (command) {
					case "source":
						this.mode = "source";
						break;
					case "editor":
						this.mode = "html";
						break;
				}
				if (this.mode == "html") {
					this._nodes.content.html.focus();
				} else {
					this._nodes.content.source.focus();
				}
				break;
			case "no-value":
			default:
				document.execCommand(command, false, null);
				if (this.mode == "html") {
					this._nodes.content.html.focus();
				} else {
					this._nodes.content.source.focus();
				}
				break;
		}
	}
	get mode() {
		return this._mode;
	}
	set mode(val) {
		if (val == "source") {
			this._nodes.content.source.innerText = HTMLEditor._filterContent(this._nodes.content.html.innerHTML);

			this._mode = "source";
			this._nodes.toolbar.source.classList.remove("html_editor_hidden");
			this._nodes.toolbar.html.classList.add("html_editor_hidden");
			this._nodes.content.source.classList.remove("html_editor_hidden");
			this._nodes.content.html.classList.add("html_editor_hidden");
		} else if (val == "html") {
			this._nodes.content.html.innerHTML = HTMLEditor._filterContent(this._nodes.content.source.innerText);

			this._mode = "html";
			this._nodes.toolbar.source.classList.add("html_editor_hidden");
			this._nodes.toolbar.html.classList.remove("html_editor_hidden");
			this._nodes.content.source.classList.add("html_editor_hidden");
			this._nodes.content.html.classList.remove("html_editor_hidden");
		}
	}
	get value() {
		if (this.mode == "html") {
			return HTMLEditor._filterContent(this._nodes.content.html.innerHTML);
		}
		return HTMLEditor._filterContent(this._nodes.content.source.innerText);
	}
	set value(html) {
		if (this.mode == "html") {
			this._nodes.content.html.innerHTML = html;
		} else {
			this._nodes.content.source.innerText = html;
		}
	}
}
{
	HTMLEditor._scriptElement = document.currentScript;
	HTMLEditor._path = HTMLEditor._scriptElement.src;
	HTMLEditor._path = HTMLEditor._path.substring(0, HTMLEditor._path.lastIndexOf("/"));

	// let node = document.createElement("script");
	// node.src = HTMLEditor._path + "/default-tools.js";
	// HTMLEditor._scriptElement.insertAdjacentElement("beforebegin", node);

	let node = document.createElement("link");
	node.setAttribute("rel", "stylesheet");
	node.setAttribute("href", HTMLEditor._path + "/html-editor-css-poyfill.css");
	HTMLEditor._scriptElement.insertAdjacentElement("afterend", node);

	delete HTMLEditor._scriptElement;

	customElements.define("html-editor", HTMLEditor);
}