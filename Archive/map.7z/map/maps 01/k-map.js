class KMap extends HTMLElement {
	static get mapBoxAccessToken() {
		return "pk.eyJ1IjoiYW5zaHVrcmlzaG5hIiwiYSI6ImNqazNzanp6ODE2bXgzcHF5Ym5mcGp1NmwifQ.re-qAn6UeqC12Gb3JYgyYA";
	}
	static get template() {
		if (typeof KMap._template == "undefined") {
			KMap._template = document.createElement("template");
			KMap._template.innerHTML = `<link rel="stylesheet" href="leaflet/leaflet.css" /><style>
			div[data-map-container] {
				display: block;
				min-height: 300px;
				box-sizing: content-box;
			}
			</style><div data-map-container></div><div style="display:none;" data-map-children-container><slot></slot></div>`;
		}
		return KMap._template;
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(KMap.template.content.cloneNode(true));
		this._mapContainer = this.shadowRoot.querySelector("[data-map-container]");
		this._mapChildrenContainer = this.shadowRoot.querySelector("[data-map-children-container]");
		this.map = L.map(this._mapContainer);
		//Set Alternative default coordinates here
		this._def_coords = [12.978129474407517, 77.59574890136719];
	}
	connectedCallback() {
		L.tileLayer(`https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token=${KMap.mapBoxAccessToken}`, {
			attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
			maxZoom: this.maxZoom,
			id: 'mapbox.streets'
		}).addTo(this.map);
		// this.map.setView([12.978129474407517, 77.59574890136719], 13);
		this.zoom = this.zoom;
		this.coords = this.coords;
		this.map.addEventListener("zoom", () => {
			this._zoom_event = true;
			this.zoom = this.map.getZoom();
		});
		this.map.addEventListener("move", () => {
			let val = this.map.getCenter();
			this._coords_event = true;
			this.coords = [val.lat, val.lng];
		});

		// this._mut_obsver = new MutationObserver((mutList)=>{
		// 	console.log("Mut", mutList);
		// });
		// this._mut_obsver.observe(this._mapChildrenContainer, {childList : true});
	}
	disconnectedCallback() {
		// this._mut_obsver.disconnect();
	}
	get coords() {
		let val = this.getAttribute("coords");
		if (val === null) return this._def_coords;
		let m = val.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
		if (m === null) return this._def_coords;
		return [parseFloat(m[1]), parseFloat(m[3])];
	}
	set coords(val) {
		if (Array.isArray(val) && val.length == 2 && !isNaN(val[0]) && !isNaN(val[1])) {
			this.setAttribute("coords", val.join(","));
		} else if (typeof val == "string") {
			this.setAttribute("coords", val);
		}
	}
	get zoom() {
		let val = this.getAttribute("zoom");
		if (val === null) return 13;
		return parseInt(val);
	}
	set zoom(val) {
		this.setAttribute("zoom", val);
	}
	get maxZoom() {
		let val = this.getAttribute("maxzoom");
		if (val === null) return 18;
		return parseInt(val);
	}
	set maxZoom(val) {
		this.setAttribute("maxzoom", val);
	}
	static get observedAttributes() {
		return ["coords", "zoom", "maxzoom"];
	}
	attributeChangedCallback(name, oldVal, newVal) {
		switch (name) {
			case "coords":
				if (this._coords_event === true) {
					delete this._coords_event;
				} else {
					if (typeof newVal == "string") {
						let m = newVal.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
						if (m === null) {
							this.removeAttribute("coords");
						}
					}
					this.map.setView(this.coords, this.zoom);
				}
				break;
			case "zoom":
				if (this._zoom_event === true) {
					delete this._zoom_event;
				} else {
					let val;
					if (typeof newVal == "string") {
						val = parseInt(newVal);
					}
					if (val < 1 && val > this.maxZoom) {
						this.removeAttribute("zoom");
					}
					this.map.setZoom(this.zoom);
				}
				break;
			case "maxzoom": {
				let val;
				if (typeof newVal == "string") {
					val = parseInt(newVal);
				}
				if (val > 18) val = 18;
				this.map.setMaxZoom(val);
			} break;
		}
	}
}

customElements.define("k-map", KMap);
/*******************************************************************/
class KMapMarker extends HTMLElement {
	static get template() {
		if (typeof KMapMarker._template == "undefined") {
			// KMapMarker._count = 0;
			KMapMarker._template = document.createElement("template");
			KMapMarker._template.innerHTML = `<link rel="stylesheet" href="leaflet/leaflet.css" /><style>[data-map-marker-children-container] {display:none;}</style><div data-map-marker-children-container><slot></slot></div>`;

			let path = "leaflet/images";
			L.Icon.Default.prototype.options.iconUrl = `${path}/${L.Icon.Default.prototype.options.iconUrl}`;
			L.Icon.Default.prototype.options.iconRetinaUrl = `${path}/${L.Icon.Default.prototype.options.iconRetinaUrl}`;
			L.Icon.Default.prototype.options.shadowUrl = `${path}/${L.Icon.Default.prototype.options.shadowUrl}`;
		}
		return KMapMarker._template;
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(KMapMarker.template.content.cloneNode(true));
		// this._count = ++KMapMarker._count;
	}
	connectedCallback() {
		this.map = null;
		this.mapElement = this.parentElement;
		// console.log(this.mapElement);
		let tag = this.mapElement.tagName.toLowerCase();
		while (tag != "k-map") {
			this.mapElement = this.mapElement.parentElement;
			tag = this.mapElement.tagName.toLowerCase();
			if(tag == "body") return;
		}
		this.map = this.mapElement.map;
		this.marker = new L.marker(this.mapElement.coords);
		this.marker.addTo(this.map);
		this._coords_event = true;
		this.coords = this.coords;
		// console.log(this._count, this.mapElement);
	}
	get coords() {
		let val = this.getAttribute("coords");
		if(this.map !== null) {
			if (val === null) return this.mapElement.coords;
			let m = val.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
			if (m === null) return this.mapElement.coords;
			return [parseFloat(m[1]), parseFloat(m[3])];
		}
		return val;
	}
	set coords(val) {
		if (Array.isArray(val) && val.length == 2 && !isNaN(val[0]) && !isNaN(val[1])) {
			this.setAttribute("coords", val.join(","));
		} else if (typeof val == "string") {
			this.setAttribute("coords", val);
		}
	}
	static get observedAttributes() {
		return ["coords"];
	}
	attributeChangedCallback(name, oldVal, newVal) {
		// console.log(this.coords, this.marker);
		switch (name) {
			case "coords":
				if (this._coords_event === true) {
					delete this._coords_event;
				} else {
					if (typeof newVal == "string") {
						let m = newVal.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
						if (m === null) {
							this.removeAttribute("coords");
						}
					}
					// console.log(this._count, this.coords, this.mapElement)
					this.map !== null && this.marker && this.marker.setLatLng(this.coords);
				}
				break;
		}
	}
}

customElements.define("k-map-marker", KMapMarker);