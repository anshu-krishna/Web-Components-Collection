class KMap extends HTMLElement {
    static get template() {
        if (typeof KMap._template == "undefined") {
            KMap._template = document.createElement("template");
            KMap._template.innerHTML = `<link rel="stylesheet" href="${KMap.__scriptPath}/leaflet/leaflet.css" />
<script src="${KMap.__scriptPath}/leaflet/leaflet.js"></script>
<style>
:host {
	background: blue;
}
#mapcntr {
	min-height: 50px;
	background: red;
}
</style><div id="mapcntr">hi</div>`;
        }
        return KMap._template;
    }
    constructor() {
        super();
        this.attachShadow({ mode: "open" });
        this.shadowRoot.appendChild(KMap.template.content.cloneNode(true));
        this.internal = { mapContainer: this.shadowRoot.querySelector('div') };
    }
    connectedCallback() {
        let map = L.map(this.internal.mapContainer).setView([51.505, -0.09], 13);
        // L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
        // attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors',
        // }).addTo(map);
    }
    // disconnectedCallback() {}
    // adoptedCallback() {}
    // static get observedAttributes() {
    // 	return [];
    // }
    // attributeChangedCallback(name, oldval, newval) {
    // console.log("Changed", name, ":", oldval, "->", newval);
    // }
}
{
    let src = document.currentScript.src;
    let index = src.lastIndexOf('/');
    KMap.__scriptPath = src.substring(0, index);
}
customElements.define("k-map", KMap);