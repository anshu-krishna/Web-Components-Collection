class KMap extends HTMLElement {
	static get _path() {
		if (typeof KMap.__script_path == "undefined") {
			let scripts = document.getElementsByTagName('script');
			let path = '.';
			if (scripts && scripts.length > 0) {
				for (let i in scripts) {
					if (scripts[i].src && scripts[i].src.match(/\/k-map\.js$/)) {
						path = scripts[i].src.replace(/(.*)\/k-map\.js$/, '$1');
						break;
					}
				}
			}
			KMap.__script_path = path;
		}
		return KMap.__script_path;
	}
	static get _template() {
		if (typeof KMap._template_node == "undefined") {
			KMap._template_node = document.createElement("template");
			KMap._template_node.innerHTML = `<link rel="stylesheet" href="${KMap._path}/leaflet/leaflet.css" />
<style>
	div[data-map-container] {
		display: block;
		min-height: 300px;
		box-sizing: content-box;
	}
	div[data-map-children-container] {
		display: none;
	}
</style>
<div data-map-container></div>
<div data-map-children-container>
	<slot></slot>
</div>`;
		}
		return KMap._template_node;
	}
	constructor() {
		super();
		this.ready = false;
		this._default = {
			center: [12.978129474407517, 77.59574890136719],
			maxZoom: 18,
			zoom: 14
		};

		this._internalEvent = {
			move: false,
			zoom: false
		}

		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(KMap._template.content.cloneNode(true));
		this._mapContainer = this.shadowRoot.querySelector("[data-map-container]");
		this._mapChildrenContainer = this.shadowRoot.querySelector("[data-map-children-container]");

		this.map = L.map(this._mapContainer);
	}

	get center() {
		let val = this.getAttribute("center");
		if (val === null) return this._default.center;
		let m = val.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
		if (m === null) return this._default.center;
		return [parseFloat(m[1]), parseFloat(m[3])];
	}
	set center(val) {
		if (Array.isArray(val) && val.length == 2 && !isNaN(val[0]) && !isNaN(val[1])) {
			this.setAttribute("center", val.join(","));
		} else if (typeof val == "string") {
			this.setAttribute("center", val);
		}
	}
	get zoom() {
		let val = this.getAttribute("zoom");
		if (val === null) return this._default.zoom;
		return parseInt(val);
	}
	set zoom(val) {
		this.setAttribute("zoom", val);
	}
	get maxZoom() {
		let val = this.getAttribute("maxzoom");
		if (val === null) return this._default.maxZoom;
		return parseInt(val);
	}
	set maxZoom(val) {
		this.setAttribute("maxzoom", val);
	}

	static get observedAttributes() {
		return ["center", "zoom", "maxzoom"];
	}
	attributeChangedCallback(name, oldval, newval) {
		(this[`_${name}_changed`])(oldval, newval);
	}
	_center_changed(oldval, newval) {
		// console.log("Center Changed", oldval, "-", newval);
		if (this._internalEvent.move === true) {
			this._internalEvent.move = false;
			this.dispatchEvent(new CustomEvent('move', { detail: this.center }));
			return;
		}
		if (newval !== null) {
			let m = String(newval).match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
			if (m === null) {
				this.removeAttribute("center");
				return;
			}
		}
		let center = this.center;
		this.map.setView(center, this.zoom);
		this.dispatchEvent(new CustomEvent('move', { detail: center }));
	}
	_zoom_changed(oldval, newval) {
		// console.log("zoom Changed", oldval, "-", newval);
		if (this._internalEvent.zoom === true) {
			this._internalEvent.zoom = false;
			this.dispatchEvent(new CustomEvent('zoom', { detail: this.zoom }));
			return;
		}
		var val;
		if (newval !== null) {
			val = parseInt(newval);
			if (val < 1) val = 1;
			if (val > this.maxZoom) val = this.maxZoom;
		} else {
			val = this._default.zoom;
		}
		oldval = parseInt(oldval);
		if (oldval != val) {
			this.map.setZoom(val);
			this.dispatchEvent(new CustomEvent('zoom', { detail: val }));
		}
	}
	_maxzoom_changed(oldval, newval) {
		// console.log("maxZoom Changed", oldval, "-", newval);
		var val;
		if (newval === null) {
			val = this._default.maxZoom;
		} else {
			val = parseInt(newval);
			if (val > this._default.maxZoom) val = this._default.maxZoom;
		}
		this.map.setMaxZoom(val);
	}

	connectedCallback() {
		this.zoom = this.zoom;
		this.center = this.center;
		this.map.setMaxZoom(this.maxZoom);

		this.map.addEventListener("move", () => {
			this._internalEvent.move = true;
			let val = this.map.getCenter();
			this.center = [val.lat, val.lng];
		});
		this.map.addEventListener("zoom", () => {
			this._internalEvent.zoom = true;
			this.zoom = this.map.getZoom();
		});

		this.addEventListener("tileLayerReady", (evt) => {
			let tileLayer = evt.detail;
			tileLayer.addTo(this.map);
		});
		this.addEventListener("tileLayerDestroy", (evt) => {
			let tileLayer = evt.detail;
			// tileLayer.addTo(this.map);
			this.map.removeLayer(tileLayer);
		});


		this.addEventListener("mapMarkerReady", (evt) => {
			let marker = evt.detail;
			marker.addTo(this.map);
		});
		this.addEventListener("mapMarkerDestroy", (evt) => {
			let marker = evt.detail;
			marker.remove();
		});
		this.addEventListener("mapMarkerMoved", (evt) => {
			console.log(evt.detail);
		});

		this.ready = true;
		this.dispatchEvent(new Event('ready'));
	}
	// disconnectedCallback() {}
}
customElements.define("k-map", KMap);
/**************************************************************************/
class MapboxTileLayer extends HTMLElement {
	static get accessToken() {
		return "pk.eyJ1IjoiYW5zaHVrcmlzaG5hIiwiYSI6ImNqazNzanp6ODE2bXgzcHF5Ym5mcGp1NmwifQ.re-qAn6UeqC12Gb3JYgyYA";
	}
	static get attributution() {
		// return `Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>`;
		return `Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>`;
	}
	static get _template() {
		if (typeof MapboxTileLayer._template_node == "undefined") {
			MapboxTileLayer._template_node = document.createElement("template");
			MapboxTileLayer._template_node.innerHTML = `<style>
div[data-tile-layer-container] {
	display: none;
}
</style>
<div data-tile-layer-container>
	<slot></slot>
</div>`;
		}
		return MapboxTileLayer._template_node;
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(MapboxTileLayer._template.content.cloneNode(true));
		this._ready = false;
	}
	/*
	Valid Map Ids: ["streets", "light", "dark", "satellite", "streets-satellite", "wheatpaste", "streets-basic", "comic", "outdoors", "run-bike-hike", "pencil", "pirates", "emerald", "high-contrast"]
	 */
	get mapid() {
		let val = this.getAttribute("mapid");
		if (val === null) return "streets";
		return val;
	}
	set mapid(val) {
		this.setAttribute("mapid", val);
	}
	_genTileLayer() {
		this.tileLayer = L.tileLayer(`https://api.tiles.mapbox.com/v4/mapbox.${this.mapid}/{z}/{x}/{y}.png?access_token=${MapboxTileLayer.accessToken}`, {
			attribution: MapboxTileLayer.attributution,
			maxZoom: 18
		});
	}
	_dispatchReady() {
		this.dispatchEvent(new CustomEvent('tileLayerReady', { detail: this.tileLayer, bubbles: true }));
	}
	_dispatchDestroy() {
		this.dispatchEvent(new CustomEvent('tileLayerDestroy', { detail: this.tileLayer, bubbles: true }));
	}
	connectedCallback() {
		this._parentMapElement = this.parentElement;
		if (this._parentMapElement.tagName.toLowerCase() != "k-map") {
			this._parentMapElement = false;
			return;
		}
		this._genTileLayer();
		this.ready = true;
		this._dispatchReady();
	}
	disconnectedCallback() {
		this._dispatchDestroy();
	}
	static get observedAttributes() {
		return ["mapid"];
	}
	attributeChangedCallback(name, oldval, newval) {
		if (name == "mapid") {
			if (oldval === null) oldval = "streets";
			if (newval === null) newval = "streets";
			if (oldval === newval) return;
			this._dispatchDestroy();
			this._genTileLayer();
			this._dispatchReady();
		}
	}
}
customElements.define("mapbox-tile-layer", MapboxTileLayer);
/**************************************************************************/
class KMapMarker extends HTMLElement {
	static get _template() {
		if (typeof KMapMarker._template_node == "undefined") {
			let path = KMap._path + "/leaflet/";
			KMapMarker._template_node = document.createElement('template');
			KMapMarker._template_node.innerHTML = `<link rel="stylesheet" href="${path}leaflet.css" /><style>
div[data-map-marker-container] {
	display:none;
}</style>
<div data-map-marker-container><slot></slot></div>`;
			((opts) => {
				for (let i of opts) {
					L.Icon.Default.prototype.options[i] = `${path}images/${L.Icon.Default.prototype.options[i]}`;
				}
			})(["iconUrl", "iconRetinaUrl", "shadowUrl"]);
		}
		return KMapMarker._template_node;
	}
	constructor() {
		super();
		this.attachShadow({ mode: "open" });
		this.shadowRoot.appendChild(KMapMarker._template.content.cloneNode(true));
		this.ready = false;
	}
	_dispatchReady() {
		this.dispatchEvent(new CustomEvent('mapMarkerReady', { detail: this.marker, bubbles: true }));
	}
	_dispatchDestroy() {
		this.dispatchEvent(new CustomEvent('mapMarkerDestroy', { detail: this.marker, bubbles: true }));
	}
	connectedCallback() {
		this._parentMapElement = this.parentElement;
		if (this._parentMapElement.tagName.toLowerCase() != "k-map") {
			this._parentMapElement = false;
			return;
		}
		this.marker = new L.marker(this._parentMapElement.center);
		this._marker = this.marker;
		this.ready = true;
		this._dispatchReady();
	}
	disconnectedCallback() {
		this._dispatchDestroy();
	}
	get latLng() {
		let val = this.getAttribute("latlng");
		if (val === null) return this._parentMapElement.center;
		let m = val.match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
		if (m === null) return this._parentMapElement.center;
		return [parseFloat(m[1]), parseFloat(m[3])];
	}
	set latLng(val) {
		if (Array.isArray(val) && val.length == 2 && !isNaN(val[0]) && !isNaN(val[1])) {
			this.setAttribute("latlng", val.join(","));
		} else if (typeof val == "string") {
			this.setAttribute("latlng", val);
		}
	}
	static get observedAttributes() {
		return ["latlng"];
	}
	attributeChangedCallback(name, oldval, newval) {
		if (name == "latlng") {
			if (newval !== null) {
				let m = String(newval).match(/(\d+(\.\d+)?)\s?,\s?(\d+(\.\d+)?)/);
				if (m === null) {
					this.removeAttribute("latlng");
					return;
				}
			}
			let latLng = this.latLng;
			// this.marker.setLatLng(latLng);
			this.dispatchEvent(new CustomEvent('mapMarkerMoved', {
				detail: {
					marker: this.marker,
					latLng: latLng
				}, bubbles: true
			}));
		}
	}
}
customElements.define("k-map-marker", KMapMarker);